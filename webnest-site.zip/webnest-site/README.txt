WebNest - ملف الموقع
====================
الملفات:
  index.html          الصفحة الرئيسية (HTML + CSS + JS في ملف واحد)
  assets/logo.webp    الشعار
  assets/founder.webp صورة المؤسس
  assets/fonts/Cairo.ttf  الخط (محلي، لا يحتاج إنترنت)

التشغيل محليًا: افتح index.html في المتصفح مباشرة.

النشر على الإنترنت (مجانًا):
  Netlify:   Add new site > Deploy manually > اسحب المجلد كامل (وليس index.html وحده)
  Cloudflare Pages: Create project > Direct Upload > ارفع المجلد
  ثم: Add custom domain واكتب دومينك، وانسخ سجلات DNS عند مزوّد الدومين.

التعديل:
  رقم واتساب: ابحث في index.html عن 96898887063 (الصيغة الدولية بدون +) و 9888 7063 (النص الظاهر).
  حساب إنستجرام: ابحث عن webnest.omani
  الأسعار والمدة: قسم الأسئلة الشائعة (FAQ) في آخر الصفحة.
